package edu.cs.birzeit.rawanapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Spinner weightSpinner;
    private LinearLayout plantLayout;
    private RecyclerView recyclerView;

    private CaptionedImagesAdapter adapter;
    private List<Item> itemList;
    private SharedPreferences sharedPreferences;
    private ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        weightSpinner = findViewById(R.id.weightSpinner);
        plantLayout = findViewById(R.id.plantLayout);
        recyclerView = findViewById(R.id.recyclerView);
        imageView = findViewById(R.id.imageView);
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        imageView.startAnimation(animation);
        ObjectAnimator rotationAnimator = ObjectAnimator.ofFloat(imageView, "rotation", 0f, 360f);
        rotationAnimator.setDuration(1000); // Set the animation duration in milliseconds
        rotationAnimator.setRepeatCount(Animation.INFINITE); // Repeat the animation indefinitely
        rotationAnimator.start();



        // Set up the Spinner
        List<String> weightOptions = new ArrayList<>();
        weightOptions.add("kg1");
        weightOptions.add("kg2");
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, weightOptions);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        weightSpinner.setAdapter(spinnerAdapter);

        // Initialize the item list
        itemList = new ArrayList<>();

        // Add your logic to populate the item list
        // For example:
        itemList.add(new Item("leaf"));
        itemList.add(new Item("stem"));
        itemList.add(new Item("root"));
        itemList.add(new Item("flower"));
        sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);

        int savedPosition = sharedPreferences.getInt("selectedPosition", 0);
        weightSpinner.setSelection(savedPosition);

        weightSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedOption = weightOptions.get(position);
                if (selectedOption.equals("kg1")) {
                    plantLayout.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.VISIBLE);

                    // Save the selected position to SharedPreferences
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putInt("selectedPosition", position);
                    editor.apply();

                    // Set up the RecyclerView with the adapter
                    recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                    recyclerView.setAdapter(adapter);
                } else {
                    plantLayout.setVisibility(View.GONE);
                    recyclerView.setVisibility(View.GONE);
                }
            }


            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }
}
